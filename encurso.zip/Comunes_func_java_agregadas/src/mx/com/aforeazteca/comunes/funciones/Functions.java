package mx.com.aforeazteca.comunes.funciones;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 *
 * @author njuarezt
 */
public class Functions {
	
    public static String reemplazar(String cadena, String a, String b) {
        return cadena.replaceAll(a, b);
    }

    public String formateaFecha(String fecha) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yy", Locale.US);
        Date fechaInicial = sdf.parse(fecha);
        SimpleDateFormat sdf2 = new SimpleDateFormat("dd/MM/yyyy");
        String fechaFinal = sdf2.format(fechaInicial);
        return fechaFinal;
    }

    public static String  reemplazaCar(String cadena) {
        String ascii = "()#$%&/=*'|°!?";
        String output = cadena;
        for (int i = 0; i < ascii.length(); i++) {
            // Reemplazamos los caracteres especiales.
            output = output.replace(String.valueOf(ascii.charAt(i)),"");
        }//for i
        if(output.trim().equals("")){
            output = "SN";
        }
        return output;
    }
        public static String  reemplazaCarDom(String cadena) {
        String ascii = "()#$%&/=*'|°!?,";
        String output = cadena;
        for (int i = 0; i < ascii.length(); i++) {
            // Reemplazamos los caracteres especiales.
            output = output.replace(String.valueOf(ascii.charAt(i)),"");
        }//for i
        if(output.trim().equals("")){
            output = "SN";
        }
        return output;
    }
}

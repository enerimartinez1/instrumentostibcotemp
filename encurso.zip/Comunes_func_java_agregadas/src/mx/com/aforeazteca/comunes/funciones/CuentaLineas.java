/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.com.aforeazteca.comunes.funciones;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author njuarezt
 */
public class CuentaLineas {

    public static int cuentaLineas(String rutaArchivo){
        int lNumeroLineas = 0;
        String sCadena="";
        try {
            FileReader fr = new FileReader(rutaArchivo);
            BufferedReader bf = new BufferedReader(fr);

            while ((sCadena = bf.readLine()) != null) {
                lNumeroLineas++;
            }
        } catch (FileNotFoundException fnfe) {
            fnfe.printStackTrace();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
        return lNumeroLineas;
    }
}

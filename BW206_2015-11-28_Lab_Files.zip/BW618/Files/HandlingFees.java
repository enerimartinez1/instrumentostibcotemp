/**
 ** BW321: Logic to calculate Handling Fees *
 ** TIBCO Education Programs 2015 ***
 **/
package com.tibco.tibedu;

public class HandlingFees {
	static String custLevel = "SILVER";
	static double orderAmount = 0.0;
	static double handlingFee = 0.0;

	public static double gethandlingFee(String custLevel, Double orderAmount) {
	 if(custLevel.equalsIgnoreCase("PLATINUM"))
		{
			if(orderAmount<=1000)
				handlingFee = 10;
			else 
				handlingFee = orderAmount*1/100;
		}
		else if(custLevel.equalsIgnoreCase("GOLD"))
		{
			if(orderAmount<=800)
				handlingFee = 20;
			else 
				handlingFee = orderAmount*2/100;
		}
		else
		{
			if(orderAmount<=800)
				handlingFee = 30;
			else 
				handlingFee = orderAmount*3/100;
		}
	return handlingFee;
	}
}

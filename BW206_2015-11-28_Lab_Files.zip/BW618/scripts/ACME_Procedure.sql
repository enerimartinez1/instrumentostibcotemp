CREATE OR REPLACE PROCEDURE CustCheck (
    cust_id           IN VARCHAR2, 	
	amount_requested  IN DECIMAL,
	cust_status       OUT VARCHAR2,                  
	comments          OUT VARCHAR2) AS
	 
	   amt_owed      DECIMAL := 0;
	   credit_limit  DECIMAL := 10000;
	   
	   CURSOR c1 IS
       SELECT amount_owed, total_credit
       FROM ACME_CUSTOMER
	   WHERE  customer_id = cust_id;

BEGIN

	OPEN c1;
	FETCH c1 INTO amt_owed, credit_limit;	
	IF c1%notfound THEN
	    INSERT INTO ACME_CUSTOMER (customer_id, amount_owed,total_credit)
         VALUES (cust_id, amount_requested, credit_limit);
		 comments := 'NEW';
		 DBMS_OUTPUT.PUT_LINE(comments);
	ELSE	
	    UPDATE ACME_CUSTOMER
		SET    amount_owed = amount_owed + amount_requested
		WHERE  customer_id = cust_id;
		DBMS_OUTPUT.PUT_LINE('Updated Customer');
		comments := 'EXISTING';
	END IF;	 
	
	DBMS_OUTPUT.PUT_LINE(amt_owed);
	DBMS_OUTPUT.PUT_LINE(credit_limit);
    IF (amt_owed + amount_requested) > credit_limit THEN  
       cust_status := 'REJECTED';
	   comments := comments || ' AND ' || 'OVERDRAWN';	   
	ELSE
	   cust_status := 'GOOD';
	   comments := comments || ' AND ' || 'ACCEPTED';
	END IF;
	
    DBMS_OUTPUT.PUT_LINE('Closing Cursor');
    CLOSE c1;
END;

/
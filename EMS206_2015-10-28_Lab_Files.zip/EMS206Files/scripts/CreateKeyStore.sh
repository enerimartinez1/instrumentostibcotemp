#!/bin/bash
#****** Clean up old files and keys *****
rm -f ems206KeyStore.jks
#****** Generate new keys ******

keytool -importcert -destkeystore ems206KeyStore.jks -file /opt/tibco/soa/ems/8.2/samples/certs/server_root.cert.pem -alias rootkey -storepass password -srcstorepass password 
 
keytool -importcert -destkeystore ems206KeyStore.jks -file /opt/tibco/soa/ems/8.2/samples/certs/server.cert.pem -alias serverkey -storepass password -srcstorepass password 

cp ems206KeyStore.jks /home/tibco/EMS206Files/keystore

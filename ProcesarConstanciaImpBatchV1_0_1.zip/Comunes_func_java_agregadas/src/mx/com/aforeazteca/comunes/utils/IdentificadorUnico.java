package mx.com.aforeazteca.comunes.utils;

import java.io.Serializable;
import java.util.UUID;

/**
 * Clase para operar un identificador unico
 *
 */
public class IdentificadorUnico implements Serializable {

	/**
	 * Serializable
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Constructor privado 
	 */
	private IdentificadorUnico(){
		
	}
	
	/**
	 * Metodo para generar un UUID
	 * @return UUID
	 */
	public static String obtenerUUID() {
		return UUID.randomUUID().toString();
	}

}

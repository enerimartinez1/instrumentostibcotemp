package mx.com.aforeazteca.comunes.funciones;


public class SplitMotivosRechazo {

    /**
     * @param args the command line arguments
     */
	public static String idMotivos (String cadena, int longitud, String delimitador){
        
        int len = cadena.length();

        // Number of parts
        int nparts = len / longitud;
        String motivos = "";

        // Break into parts
        int offset= 0;
        int i = 0;
        while (i < nparts)
        {
            String motivo = cadena.substring(offset, Math.min(offset + longitud, len));
			if ((nparts-1) == i){
				motivos += motivo;
			}else{
				motivos += motivo + ",";
			}
            offset += longitud;
            i++;
        }

        return motivos;
    }
    
}
